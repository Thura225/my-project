<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "fashiondb";
//connection
$con = mysqli_connect($host, $user, $pass, $db);

//db selection

?>